#include <gtk/gtk.h>


void
on_hazemkh_inscri_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazemkh_connecter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazemkh_femme_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hazemkh_homme_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hazem33inscrit_enter                (GtkWidget       *objet_graphique,gpointer  user_data);

void
on_hazemtreeview1_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_hazemkh_ajouter2_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazem_modifier_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazemkhrecherche_clicked            (GtkWidget       *objet_graphique,gpointer  user_data);

void
on_hazemkh_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazemkh_actualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_hazemhomme11_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hazem_radiobuton666modif_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_hazem_non_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hazem_ajout_tache2_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazem_bouton_hk_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazem_bouton_eleve_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_hazem_modifer55_clicked             (GtkWidget       *objet_graphique,gpointer  user_data);

void
on_hazem_confermation_ok_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_yessshazem_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_hazem_recharger_clicked             (GtkWidget       *objet_graphique,gpointer  user_data);


void
on_button12_retour_kh_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quiter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

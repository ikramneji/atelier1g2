#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
#include <stdio.h>
#include <stdlib.h>



holybody z;
userty p;

int h;
int g[2];

/*   bouton inscription dans la fenêtre Authentification  */

void
on_hazemkh_inscri_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowr,*Authentification;
windowr=create_Inscription();
gtk_widget_show (windowr);
Authentification = lookup_widget(button,"Authentification");
gtk_widget_destroy(Authentification);
}

/*   bouton connecter dans la fenêtre Authentification  */

void
on_hazemkh_connecter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *nom, *prenom;
int eio;
nom=lookup_widget(button,"hazemusername");
prenom=lookup_widget(button,"hazemmotpasse");

eio=login( gtk_entry_get_text(GTK_ENTRY(nom)),gtk_entry_get_text(GTK_ENTRY(prenom)));

if(eio==1)
{
    GtkWidget *windo;
windo=create_Dashbord();
gtk_widget_show (windo);
}
else if (eio==2)
{
    GtkWidget *affiche_etud ;
affiche_etud=create_affiche_etud();
gtk_widget_show (affiche_etud);
}
else if (eio==3)
{
     GtkWidget *windowr;
windowr=create_menu();
gtk_widget_show (windowr);
}
}

/* radio button femme da la fentêre "insncription"   */
void
on_hazemkh_femme_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{



if(gtk_toggle_button_get_active(togglebutton))
h=1;




}

/*  radio button "homme" da la fentêre "insncription"   */
void
on_hazemkh_homme_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if(gtk_toggle_button_get_active(togglebutton))
h=2;

}

/*  bouton "inscrir" de la fenêtre "inscription"  */

void
on_hazem33inscrit_enter                (GtkWidget       *objet_graphique,gpointer  user_data)


{



holybody z;

int xe;

GtkWidget *nom, *prenom, *cin, *role, *email, *mdp;
GtkWidget *jouro;
GtkWidget *moiso;
GtkWidget *annneo;
nom=lookup_widget(objet_graphique,"hazemkh_nom");
prenom=lookup_widget(objet_graphique,"hazemkh_prenom");
cin=lookup_widget(objet_graphique,"hazemkh_cin");
email=lookup_widget(objet_graphique,"hazemkh_email");
mdp=lookup_widget(objet_graphique,"hazemkh_mdp");
jouro=lookup_widget(objet_graphique,"spinbutton1_hazem");
moiso=lookup_widget(objet_graphique,"spinbutton2_hazemmois");
annneo=lookup_widget(objet_graphique,"spinbutton3_hazzzem");
role=lookup_widget(objet_graphique,"combobox1_role");

if(strcmp("Administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Administrateur");

else if(strcmp("Direction",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Direction");
else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Technicien");
else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Nutritionniste");
else if(strcmp("AgentFoyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"AgentFoyer");
else if(strcmp("AgentRestaurant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"AgentRestaurant");
else if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
{
strcpy(z.Role,"Etudiant");


GtkWidget *windowr;
windowr=create_Eleve();
gtk_widget_show (windowr);



}



z.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jouro));
z.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(moiso));
z.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annneo));



strcpy(z.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(z.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(z.Cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(z.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(z.Modps,gtk_entry_get_text(GTK_ENTRY(mdp)));


 if (h==2) 
strcpy(z.sexe,"Homme");
else if(h==1)
strcpy(z.sexe,"Femme");

/*  vérification de CIN */

xe=verification(z);
if(xe==0)
ajouter_1(z);
else if (xe==1)
{

GtkWidget *verification;
verification=create_verification();
gtk_widget_show (verification);
}
}

/*  treeview de "dashbord" pour les utilisateurs  */
void
on_hazemtreeview1_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* nom;
gchar* prenom;
gchar* Cin;
gchar* Email;
gchar* Modps;
gchar* Role;
gchar* sexe;

GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&jour,1,&mois,2,&annee,3,&nom,4,&prenom,5,&Cin,6,&Email,7,&Modps,8,&Role,9,&sexe,-1);
strcpy(p.jour,jour);
strcpy(p.mois,mois);
strcpy(p.annee,annee);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.Cin,Cin);
strcpy(p.Email,Email);
strcpy(p.Modps,Modps);
strcpy(p.Role,Role);
strcpy(p.sexe,sexe);
}
}

/*  bouton "ajouter" de "dashbord"  */
void
on_hazemkh_ajouter2_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowr;
windowr=create_Inscription();
gtk_widget_show (windowr);
}

/*  bouton "modifier" de "dashbord"  */
void
on_hazem_modifier_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowre;
windowre=create_modificationhazem();
gtk_widget_show (windowre);
}

/*  bouton "Recherche" de "dashbord"  */
void
on_hazemkhrecherche_clicked            (GtkWidget       *objet_graphique,gpointer  user_data)
{



GtkWidget *treevieww;

treevieww=lookup_widget(objet_graphique,"hazemtreeview1");
char n[20];
char p[20];


GtkWidget *email;
GtkWidget *cin;

email=lookup_widget(objet_graphique,"hazem_recherche_cin");
cin=lookup_widget(objet_graphique,"hazem_recherche_entryo");
strcpy(n,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(p,gtk_entry_get_text(GTK_ENTRY(cin)));
chercher(n,p,treevieww);
}

/*  bouton Supprimer de dashbord  */
void
on_hazemkh_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowre;
windowre=create_hazemconfirmation();
gtk_widget_show (windowre);

}

/*  bouton actualiser de dashbord  */
void
on_hazemkh_actualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;


treeview=lookup_widget(button,"hazemtreeview1");
 affich(treeview);




}

/*  bouton homme de modification  */
void
on_radiobutton_hazemhomme11_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
h=2;
}

/*  bouton Femme de la fenetre "modification"  */
void
on_hazem_radiobuton666modif_toggled    (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
h=1;

}

/*  check button "Non" de la fenêtre "confirmation" */
void
on_checkbutton_hazem_non_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
g[1]=3;

}

/*  confirmation de niveau de l'etudiant de la fenrêtre "Eleve"  */
void
on_hazem_ajout_tache2_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *uuyt;
char hp[20];

uuyt=lookup_widget(button,"combobox1_hazzrty");
if(strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(uuyt)))==0)
strcpy(hp,"1");
if(strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(uuyt)))==0)
strcpy(hp,"2");

if(strcmp("3",gtk_combo_box_get_active_text(GTK_COMBO_BOX(uuyt)))==0)
strcpy(hp,"3");

if(strcmp("4",gtk_combo_box_get_active_text(GTK_COMBO_BOX(uuyt)))==0)
strcpy(hp,"4");

if(strcmp("5",gtk_combo_box_get_active_text(GTK_COMBO_BOX(uuyt)))==0)
strcpy(hp,"5");
ajouter_2(hp);
}

/*  boutton pour affichier les niveaux des etudiants dans la fenetre tache2  */ 
void
on_hazem_bouton_hk_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
   
GtkWidget *treeview;

treeview=lookup_widget(button,"hazem_treeview2");
 NiveauEtud(treeview);
}

/*  boutton etoile de la fênetre "dashbord" pour deriger vers la fenêtre "Eleve"   */ 
void
on_hazem_bouton_eleve_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowre;
windowre=create_tache2();
gtk_widget_show (windowre);
}

/* bouton "modifier" de la fenêtre "modificion"   */
void
on_hazem_modifer55_clicked             (GtkWidget       *objet_graphique,gpointer  user_data)
{
holybody z;
int xe;


GtkWidget *nom, *prenom, *cin, *role, *email, *mdp,*calanderofthisar;
GtkWidget *jouro;
GtkWidget *moiso;
GtkWidget *annneo;
nom=lookup_widget(objet_graphique,"hazemttds");
prenom=lookup_widget(objet_graphique,"hazemyy");
cin=lookup_widget(objet_graphique,"hazemkh556");
email=lookup_widget(objet_graphique,"hazem77");
mdp=lookup_widget(objet_graphique,"hazemkhttr");
role=lookup_widget(objet_graphique,"hazemcombomodif");
calanderofthisar=lookup_widget(objet_graphique,"calendar1hazem");


if(strcmp("Administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Administrateur");

else if(strcmp("Direction",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Direction");
else if(strcmp("Technicien",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Technicien");
else if(strcmp("Nutritionniste",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"Nutritionniste");
else if(strcmp("AgentFoyer",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"AgentFoyer");
else if(strcmp("AgentRestaurant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
strcpy(z.Role,"AgentRestaurant");
else if(strcmp("Etudiant",gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)))==0)
{
strcpy(z.Role,"Etudiant");


}

gtk_calendar_get_date(GTK_CALENDAR(calanderofthisar),
                          &z.annee,
                          &z.mois,
                          &z.jour);



strcpy(z.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(z.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(z.Cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(z.Email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(z.Modps,gtk_entry_get_text(GTK_ENTRY(mdp)));


 if (h==2) 
strcpy(z.sexe,"Homme");
else if(h==1)
strcpy(z.sexe,"Femme");




modifier_reclam(p,z);

}

/*  bouton "ok" de la fenêtre "confirmation"  */
void
on_hazem_confermation_ok_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *hazemconfirmation,*Dashbord;

if (g[0]==1)
supprimer_reclam(p);
else
g[1]=3;


hazemconfirmation = lookup_widget(button,"hazemconfirmation");
gtk_widget_destroy(hazemconfirmation);


}

/*  check button "Yes" de la fenêtre "confirmation" */

void
on_checkbutton1_yessshazem_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
g[0]=1;

}

/*   bouton de "recharger" les textes dans la fenêtre "modification"  */
void
on_hazem_recharger_clicked             (GtkWidget       *objet_graphique,gpointer  user_data)
{



GtkWidget *nom, *prenom, *cin, *role, *email, *mdp,*calanderofthisar;
GtkWidget *jouro;
GtkWidget *moiso;
GtkWidget *annneo;
nom=lookup_widget(objet_graphique,"hazemttds");
prenom=lookup_widget(objet_graphique,"hazemyy");
cin=lookup_widget(objet_graphique,"hazemkh556");
email=lookup_widget(objet_graphique,"hazem77");
mdp=lookup_widget(objet_graphique,"hazemkhttr");
role=lookup_widget(objet_graphique,"hazemcombomodif");

gtk_entry_set_text(GTK_ENTRY(nom),p.nom);
gtk_entry_set_text(GTK_ENTRY(prenom),p.prenom);
gtk_entry_set_text(GTK_ENTRY(cin),p.Cin);
gtk_entry_set_text(GTK_ENTRY(email),p.Email);
gtk_entry_set_text(GTK_ENTRY(mdp),p.Modps);
gtk_entry_set_text(GTK_ENTRY(role),p.Role);






}

/* bouton retour de l'inscription vers l'authentification  */
void
on_button12_retour_kh_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Authentification,*Inscription;
Inscription = lookup_widget(button,"Inscription");
gtk_widget_destroy(Inscription);
Authentification = create_Authentification();
gtk_widget_show(Authentification);

}


#include <gtk/gtk.h>


void afficher_peti_dej(char fname [],GtkWidget *liste);
void supprimer_pdej ( char fname[] ,char dt []);
int recherche_pdej(char nom[]);
void modifier (char fname [],char c [],pdej p);
void modif_pdej(int a,char cafe[20],char viennoiserie[20],char jus[20],char date[100]);


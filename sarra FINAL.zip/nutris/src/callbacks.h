#include <gtk/gtk.h>


void
on_pti_dej_menu_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_dej_menu_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_list_menu_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_din_menu_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_pti_dej_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_dej_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radio_avec_regime_dej_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radio_sans_regime_dej_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_avec_regime_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_sans_regime_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_add_dinnee_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_F5_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_modif_menu_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_rech_edit_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_s_back_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_sr_edit_valid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_edit_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_annuler_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ss_best_menu_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_ss_best_menu_w_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

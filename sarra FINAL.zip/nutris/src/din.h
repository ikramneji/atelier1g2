#include <gtk/gtk.h>


void afficher_din(char fname [],GtkWidget *liste);
void supprimer_din ( char fname[] ,char e []);
int recherche_din(char nom[]);
void modif_din(int a,char dn_entree[20],char dn_plat_p[20],char dn_dessert[20],char date[100]);
void modifier_din (char fname [],char e [],din dn);


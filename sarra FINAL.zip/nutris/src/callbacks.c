#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "nutr.h"
#include "pdej.h"
#include "dej.h"
#include "din.h"

int e=1;
void
on_list_menu_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu, *dashboard;

dashboard=lookup_widget(objet,"dashboard");

//gtk_widget_destroy(menu);
dashboard=create_dashboard();
gtk_widget_show(dashboard);
}


void
on_din_menu_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu, *dinnee;

menu=lookup_widget(objet,"menu");

//gtk_widget_destroy(menu);
dinnee=create_dinnee();
gtk_widget_show(dinnee);
}


void
on_pti_dej_menu_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu, *petit_dej;

menu=lookup_widget(objet,"menu");

//gtk_widget_destroy(menu);
petit_dej=create_petit_dej();
gtk_widget_show(petit_dej);
}


void
on_dej_menu_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu, *dejeune;

menu=lookup_widget(objet,"menu");

//gtk_widget_destroy(menu);
dejeune=create_dejeune();
gtk_widget_show(dejeune);
}


void
on_add_pti_dej_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{

char sj [100];
char sm [100];
char sa [100];
char dt [100];
int j;
int m;
int n;

GtkWidget *input_cafe, *input_viennoiserie, *input_jus, *input_jour, *input_mois, *input_annee ;
GtkWidget *petit_dej;

pdej p;

petit_dej=lookup_widget(objet,"petit_dej");

input_cafe=lookup_widget(objet,"entry_cafe");
input_viennoiserie=lookup_widget(objet,"entry_vin");
input_jus=lookup_widget(objet,"entry_jus");
input_jour=lookup_widget(objet,"pti_dej_jour");
input_mois=lookup_widget(objet,"pti_dej_mois");
input_annee=lookup_widget(objet,"pti_dej_annee");

strcpy(p.cafe,gtk_entry_get_text(GTK_ENTRY(input_cafe)));
strcpy(p.viennoiserie,gtk_entry_get_text(GTK_ENTRY(input_viennoiserie)));
strcpy(p.jus,gtk_entry_get_text(GTK_ENTRY(input_jus)));

j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_jour));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_mois));
n=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_annee));

sprintf(sj,"%d",j);
sprintf(sm,"%d",m);
sprintf(sa,"%d",n);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm);
strcpy(dt,sj);

strcpy(p.date,dt);
ajouter_pdej ("petit_dej.txt",p);


GtkWidget *add_succe;
add_succe = create_add_succe ();
gtk_widget_show (add_succe);
}


void
on_add_dej_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

char sj [100];
char sm [100];
char sa [100];
char dt [100];
int j;
int m;
int n;

GtkWidget *input_entree, *input_plat_p, *input_dessert, *input_jour, *input_mois, *input_annee ;
GtkWidget *dejeune;

dej dj;

dejeune=lookup_widget(objet,"dejeune");

input_plat_p=lookup_widget(objet,"entry_plat_dej");
input_entree=lookup_widget(objet,"entry_entree_dej");
input_dessert=lookup_widget(objet,"combo_dessert_dej");
input_jour=lookup_widget(objet,"dej_jour");
input_mois=lookup_widget(objet,"dej_mois");
input_annee=lookup_widget(objet,"dej_annee");

strcpy(dj.dj_plat_p,gtk_entry_get_text(GTK_ENTRY(input_plat_p)));
strcpy(dj.dj_entree,gtk_entry_get_text(GTK_ENTRY(input_entree)));
strcpy(dj.dj_dessert,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input_dessert)));


j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_jour));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_mois));
n=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_annee));


sprintf(sj,"%d",j);
sprintf(sm,"%d",m);
sprintf(sa,"%d",n);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm);
strcpy(dt,sj);

strcpy(dj.date,dt);
ajouter_dej ("dej.txt",dj);


GtkWidget *add_succe;
add_succe = create_add_succe ();
gtk_widget_show (add_succe);
}


void
on_radio_avec_regime_dej_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radio_sans_regime_dej_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_check_sans_regime_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_add_dinnee_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{

char sj [100];
char sm [100];
char sa [100];
char dt [100];
int j;
int m;
int n;

GtkWidget *input_entree_din, *input_plat_p_din, *input_dessert_din, *input_jour_din, *input_mois_din, *input_annee_din ;
GtkWidget *dejeune;

din dn;

dejeune=lookup_widget(objet,"dejeune");

input_plat_p_din=lookup_widget(objet,"entry_plat_din");
input_entree_din=lookup_widget(objet,"entry_entree_din");
input_dessert_din=lookup_widget(objet,"combo_dessert_din");
input_jour_din=lookup_widget(objet,"din_jour");
input_mois_din=lookup_widget(objet,"din_mois");
input_annee_din=lookup_widget(objet,"din_annee");


strcpy(dn.dn_plat_p,gtk_entry_get_text(GTK_ENTRY(input_plat_p_din)));
strcpy(dn.dn_entree,gtk_entry_get_text(GTK_ENTRY(input_entree_din)));
strcpy(dn.dn_dessert,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input_dessert_din)));


j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_jour_din));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_mois_din));
n=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_annee_din));


sprintf(sj,"%d",j);
sprintf(sm,"%d",m);
sprintf(sa,"%d",n);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm);
strcpy(dt,sj);

strcpy(dn.date,dt);
ajouter_din ("din.txt",dn);


GtkWidget *add_succe;
add_succe = create_add_succe ();
gtk_widget_show (add_succe);
}


void
on_check_avec_regime_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}

pdej p;
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* cafe;
	gchar* viennoiserie;
	gchar* jus;
	gchar* date;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0, &cafe,1, &viennoiserie,2,&jus,3,&date,-1);
//copie des valeurs dans la variable P de type personne pour le passer  à la fonction de suppression
		strcpy(p.cafe,cafe);
		strcpy(p.viennoiserie,viennoiserie);
		strcpy(p.jus,jus);
		strcpy(p.date,date);
}
}

dej dj;
void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	GtkTreeIter iter;
	gchar* dj_entree;
	gchar* dj_plat_p;
	gchar* dj_dessert;
	gchar* date;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0, &dj_entree,1, &dj_plat_p,2,&dj_dessert,3,&date,-1);
//copie des valeurs dans la variable P de type personne pour le passer  à la fonction de suppression
		strcpy(dj.dj_entree,dj_entree);
		strcpy(dj.dj_plat_p,dj_plat_p);
		strcpy(dj.dj_dessert,dj_dessert);
		strcpy(dj.date,date);
}
}

din dn;
void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* dn_entree;
	gchar* dn_plat_p;
	gchar* dn_dessert;
	gchar* date;
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0, &dn_entree,1, &dn_plat_p,2,&dn_dessert,3,&date,-1);
//copie des valeurs dans la variable P de type personne pour le passer  à la fonction de suppression
		strcpy(dn.dn_entree,dn_entree);
		strcpy(dn.dn_plat_p,dn_plat_p);
		strcpy(dn.dn_dessert,dn_dessert);
		strcpy(dn.date,date);
}
}


void
on_F5_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dashboard;
GtkWidget *treeview1, *treeview4, *treeview3;
dashboard = lookup_widget(objet,"dashboard");
gtk_widget_destroy(dashboard);
dashboard=create_dashboard ();
gtk_widget_show (dashboard);
treeview1 = lookup_widget(dashboard,"treeview1");
treeview4 = lookup_widget(dashboard,"treeview4");
treeview3 = lookup_widget(dashboard,"treeview3");
afficher_peti_dej("petit_dej.txt",treeview1);
afficher_dej("dej.txt",treeview3);
afficher_din("din.txt",treeview4);
}


void
on_modif_menu_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *dashboard, *sr_Modification;

dashboard=lookup_widget(objet_graphique,"dashboard");

sr_Modification=create_sr_Modification();
gtk_widget_show(sr_Modification);
}


void
on_rech_edit_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input_sarra;
GtkWidget* input_jour;
GtkWidget* input_mois;
GtkWidget* input_annee;

	char cafe[30];
	char viennoiserie[30];
	char jus[30];
	int j;
	int m;
	char sj [100];
	char sm [100];
	char date[100];
	char sarra[30];

GtkWidget	*input_cafe		=	lookup_widget(objet,"entry2");
GtkWidget	*input_viennoiserie	=	lookup_widget(objet,"entry3");
GtkWidget	*input_jus		=	lookup_widget(objet,"entry4");
/**---------------------------------------------------------------**/
	char dj_entree[30];
	char dj_plat_p[30];
	char dj_dessert[30];
GtkWidget	*input_entree	=	lookup_widget(objet,"entry2");
GtkWidget	*input_plat_p	=	lookup_widget(objet,"entry3");
GtkWidget	*input_dessert	=	lookup_widget(objet,"entry4");
/**------------------------------------------------------------------**/
	char dn_entree[30];
	char dn_plat_p[30];
	char dn_dessert[30];
GtkWidget	*input_dn_entree	=	lookup_widget(objet,"entry2");
GtkWidget	*input_dn_plat_p	=	lookup_widget(objet,"entry3");
GtkWidget	*input_dn_dessert	=	lookup_widget(objet,"entry4");



input_sarra=lookup_widget(objet,"comboboxentry1");

char nom[20];
GtkWidget	*input		=	lookup_widget(objet,"entry1");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input)));

int a=0;
/**----------------------------------------------------------------------**/

if (strcmp(strcpy(sarra,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input_sarra))),"Petit_dej")==0)
{
a=recherche_pdej(nom);
if (a==-1)
{
  GtkWidget *dialog, *meilleur_menu;
  dialog = gtk_message_dialog_new(GTK_WINDOW(meilleur_menu),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "Menu n'existe pas");
  gtk_window_set_title(GTK_WINDOW(dialog), "Alerte");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
}
else 
{
modif_pdej(a,cafe,viennoiserie,jus,date);
gtk_entry_set_text (GTK_ENTRY(input_cafe),cafe);
gtk_entry_set_text (GTK_ENTRY(input_viennoiserie),viennoiserie);
gtk_entry_set_text (GTK_ENTRY(input_jus),jus);
}
}
/**----------------------------------------------------------------------**/
else if (strcmp(strcpy(sarra,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input_sarra))),"Dejeune")==0)
{
a=recherche_dej(nom);
if (a==-1)
{
  GtkWidget *dialog1, *meilleur_menu;
  dialog1 = gtk_message_dialog_new(GTK_WINDOW(meilleur_menu),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "Menu n'existe pas");
  gtk_window_set_title(GTK_WINDOW(dialog1), "Alerte");
  gtk_dialog_run(GTK_DIALOG(dialog1));
  gtk_widget_destroy(dialog1);
}
else 
{
modif_dej(a,dj_entree,dj_plat_p,dj_dessert,date);
gtk_entry_set_text (GTK_ENTRY(input_entree),dj_entree);
gtk_entry_set_text (GTK_ENTRY(input_plat_p),dj_plat_p);
gtk_entry_set_text (GTK_ENTRY(input_dessert),dj_dessert);
}
}
/**----------------------------------------------------------------------**/
else if (strcmp(strcpy(sarra,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input_sarra))),"Dinnee")==0)
{
a=recherche_din(nom);
if (a==-1)
{
  GtkWidget *dialog2, *meilleur_menu;
  dialog2 = gtk_message_dialog_new(GTK_WINDOW(meilleur_menu),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "Menu n'existe pas");
  gtk_window_set_title(GTK_WINDOW(dialog2), "Alerte");
  gtk_dialog_run(GTK_DIALOG(dialog2));
  gtk_widget_destroy(dialog2);
}
else 
{
modif_din(a,dn_entree,dn_plat_p,dn_dessert,date);
gtk_entry_set_text (GTK_ENTRY(input_dn_entree),dn_entree);
gtk_entry_set_text (GTK_ENTRY(input_dn_plat_p),dn_plat_p);
gtk_entry_set_text (GTK_ENTRY(input_dn_dessert),dn_dessert);
}
}
}

void
on_modif_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
calander c;
pdej p;
GtkWidget* input2;
GtkWidget* input3;
GtkWidget* input4;
GtkWidget* input_jour;
GtkWidget* input_mois;
GtkWidget* input_annee;
GtkWidget* calander_sarra;

calander_sarra=lookup_widget(objet_graphique,"calendar_sarra");
input2= lookup_widget(objet_graphique, "entry2");
input3= lookup_widget(objet_graphique, "entry3");
input4= lookup_widget(objet_graphique, "entry4");
/**----------------------------------------------------------------**/

input_jour= lookup_widget(objet_graphique, "sp_j");
input_mois= lookup_widget(objet_graphique, "sp_m");
input_annee= lookup_widget(objet_graphique, "sp_a");
char v [100];
char jus [100];
char cafe [100];
int j ;
int m;
int a;
char sc [100];
char sj [100];
char sm [100];
char sa [100];
char date [100];

strcpy(cafe,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(jus,gtk_entry_get_text(GTK_ENTRY(input4)));
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_jour));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_mois));
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_annee));

pdej pjn;
strcpy(pjn.cafe,cafe);
strcpy(pjn.viennoiserie,v);
strcpy(pjn.jus,jus);

gtk_calendar_get_date(GTK_CALENDAR(calander_sarra),
                          &c.a,
                          &c.m,
                          &c.j);  // copier le jour / mois / annee


c.m=c.m+1;
sprintf(sj,"%d",c.j);
sprintf(sm,"%d",c.m);
sprintf(sa,"%d",c.a);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm+1);
strcpy(date,sj);
strcpy(pjn.date,date);
modifier("petit_dej.txt",pjn.cafe,pjn);

/*---------------------------------------------*/
/*-----------------------------------------------*/
GtkWidget *pInfo2;
pInfo2=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous vraiment\nmodifier ce menu?");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo2)))
	{
	case GTK_RESPONSE_YES:
	gtk_widget_destroy(pInfo2);

/*---------------------------------------------*/
dej djn;
dej dj;

strcpy(cafe,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(jus,gtk_entry_get_text(GTK_ENTRY(input4)));


strcpy(djn.dj_entree,cafe);
strcpy(djn.dj_plat_p,v);
strcpy(djn.dj_dessert,jus);


gtk_calendar_get_date(GTK_CALENDAR(calander_sarra),
                          &c.a,
                          &c.m,
                          &c.j);  // copier le jour / mois / annee
c.m=c.m+1;
sprintf(sj,"%d",c.j);
sprintf(sm,"%d",c.m);
sprintf(sa,"%d",c.a);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm);
strcpy(date,sj);
strcpy(djn.date,date);

modifier_dej("dej.txt",djn.dj_entree,djn);

/*--------------------------------------------------*/
din dnn;
din dn;

strcpy(cafe,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(v,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(jus,gtk_entry_get_text(GTK_ENTRY(input4)));


strcpy(dnn.dn_entree,cafe);
strcpy(dnn.dn_plat_p,v);
strcpy(dnn.dn_dessert,jus);

gtk_calendar_get_date(GTK_CALENDAR(calander_sarra),
                          &c.a,
                          &c.m,
                          &c.j);  // copier le jour / mois / annee

c.m=c.m+1;
sprintf(sj,"%d",c.j);
sprintf(sm,"%d",c.m);
sprintf(sa,"%d",c.a);
strcat(sj,"/");
strcat(sm,"/");
strcat(sm,sa);
strcat(sj,sm);
strcpy(date,sj);
strcpy(dnn.date,date);

modifier_din("din.txt",dnn.dn_entree,dnn);

        break;
	case GTK_RESPONSE_NO:
	gtk_widget_destroy(pInfo2);
	break;
}
}



void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *confirm, *dashboard;

dashboard=lookup_widget(objet,"dashboard");

confirm=create_confirm_supp();
gtk_widget_show(confirm);
}


void
on_s_back_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dashboard, *sr_Modification;

sr_Modification=lookup_widget(objet,"sr_Modification");

gtk_widget_destroy(sr_Modification);
}

int g[2];
void
on_sr_edit_valid_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
if (g[0]==1)
{
supprimer_pdej("petit_dej.txt",p.cafe);
supprimer_dej ("dej.txt" ,dj.dj_entree);
supprimer_din ("din.txt" ,dn.dn_entree);

GtkWidget *confirm_supp;
confirm_supp=lookup_widget(objet,"confirm_supp");
gtk_widget_destroy(confirm_supp);
}
if (g[1]==3)
{
GtkWidget *confirm_supp;
confirm_supp=lookup_widget(objet,"confirm_supp");
gtk_widget_destroy(confirm_supp);
}
}


void
on_check_edit_toggled                  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
g[0]=1;
}


void
on_check_annuler_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
g[1]=3;
}


void
on_ss_best_menu_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *dialog, *meilleur_menu;
  dialog = gtk_message_dialog_new(GTK_WINDOW(meilleur_menu),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,
            GTK_BUTTONS_OK,
            "Unallowed operation");
  gtk_window_set_title(GTK_WINDOW(dialog), "Warning");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
}


void
on_ss_best_menu_w_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dashboard, *meilleur_menu;

dashboard=lookup_widget(objet,"dashboard");

meilleur_menu=create_meilleur_menu();
gtk_widget_show(meilleur_menu);
}


#include <gtk/gtk.h>


void afficher_dej(char fname [],GtkWidget *liste);
void supprimer_dej ( char fname[] ,char e []);
int recherche_dej(char nom[]);
void modif_dej(int a,char dj_entree[20],char dj_plat_p[20],char dj_dessert[20],char date[100]);
void modifier_dej (char fname [],char e [],dej dj);


#include <gtk/gtk.h>


void
on_iktreeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ikbutton_ok_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton_logout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton_chercher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_iktreeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ikbutton6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton1_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_ikradiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikradiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikbuttonV_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_ikbuttonVV_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_ikbutton3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikradiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikradiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikbutton5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikcheckbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikcheckbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikbutton8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikradiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikradiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ikbutton11_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton13_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton14_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ikbutton15_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


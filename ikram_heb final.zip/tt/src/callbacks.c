#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ikfonction.h"
int supp;
int payement,payementm;
char refch[10];
void
on_iktreeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkWidget *principale;
	
	GtkTreeIter iter;
	gchar *nb;
	gchar *etage;
	
	eheb e;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		

		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&etage,1,&nb,-1);
		
		
		affich(treeview);
}
}


void
on_ikbutton_ok_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *classe, *outputMsg;char class[20];
float s=0,i=0;
char text[60];eheb e;
classe = lookup_widget (button,"ikentry8");
strcpy(class,gtk_entry_get_text(GTK_ENTRY(classe)));
FILE *f=NULL;

f=fopen("ikfichier.txt","r");
if(fscanf(f,"%s %s %s %s %s %d %d %d %d\n",e.id,e.nom,e.prenom,e.classe,
e.refch,&e.payement,&e.date_entree.jour,&e.date_entree.mois,&e.date_entree.annee)!=EOF){
while(fscanf(f,"%s %s %s %s %s %d %d %d %d\n",e.id,e.nom,e.prenom,e.classe,
e.refch,&e.payement,&e.date_entree.jour,&e.date_entree.mois,&e.date_entree.annee)!=EOF)
{i=i+1;
if(strcmp(e.classe,class)==0)
     s=s+1;}fclose(f);s=(float)s*100/i;sprintf(text, "%.2f", s);strcat(text,"%");
	     outputMsg=lookup_widget(button,("iklabel38"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);}
else {outputMsg=lookup_widget(button,("iklabel38"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),"0%");}
}


void
on_ikbutton_logout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ikbutton_chercher_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *idd, *outputMsg;
char id[20];char ch[10];strcpy(ch," ");
char text[60];
idd = lookup_widget (button,"ikentry_chercher");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idd)));
if (chercher_heb(id)==-1){
strcpy (text,"id introuvable");
	     outputMsg=lookup_widget(button,("iklabel36"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
else {
FILE *f=NULL;
eheb e;
f=fopen("ikfichier.txt","r");

while(fscanf(f,"%s %s %s %s %s %d %d %d %d\n",e.id,e.nom,e.prenom,e.classe,
e.refch,&e.payement,&e.date_entree.jour,&e.date_entree.mois,&e.date_entree.annee)!=EOF)
{
if(strcmp(e.id,id)==0)
     {
 strcpy (text,strcat(e.nom,strcat(ch,strcat(e.prenom,strcat(ch,e.classe)))));}}fclose(f);
	     outputMsg=lookup_widget(button,"iklabel36");
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);}

}



void
on_iktreeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *principale;
	
	GtkTreeIter iter;
	gchar *nom;
	gchar *prenom;
	gchar *id;
	gchar *classe;
	gchar *refch;
	gint payement;
	gint jour;
	gint mois;	
	gint annee;
	
	eheb e;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		

		gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&prenom,3,&classe,4,&refch,5,&payement,6,&jour,7,&mois,8,&annee,-1);
		
		strcpy(e.id,id);
		strcpy(e.nom,nom);
		strcpy(e.prenom,prenom);
		strcpy(e.classe,classe);
		strcpy(e.refch,refch);
		e.payement=payement;
		e.date_entree.jour=jour;
		e.date_entree.mois=mois;
		e.date_entree.annee=annee;
		affiche_heb(treeview);
}
}


void
on_ikbutton6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)

{
GtkWidget *treeview,*principale;
principale=lookup_widget(button,"ikprincipale");
treeview=lookup_widget(principale,"iktreeview2");
affiche_heb(treeview);
}






void
on_ikbutton1_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *idd,*nom,*prenom,*classe,*Ajouter,*outputMsg;
Ajouter=lookup_widget(objet_graphique,"ikAjouter");
eheb e ;
char id[20];
GtkWidget  *combobox8,*combobox9,*combobox10;
char bloc[10];char etage[10];char num[10];


idd = lookup_widget (objet_graphique,"ikentry1");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idd)));
if (chercher_heb(id)==-1)
{
strcpy(e.id,id);
combobox8 = lookup_widget (objet_graphique,"ikcombobox8");
combobox9 = lookup_widget (objet_graphique,"ikcombobox9");
combobox10 = lookup_widget (objet_graphique,"ikcombobox10");
if (strcmp("A",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"A");
if (strcmp("B",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"B");
if (strcmp("C",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"C");

if (strcmp("0",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"0");
if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"2");

if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"2");
if (strcmp("3",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"3");
if (strcmp("4",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"4");
if (strcmp("5",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"5");
if (strcmp("6",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"6");
if (strcmp("7",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"7");
if (strcmp("8",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"8");
strcpy(e.refch,strcat(strcat(bloc,etage),num));

nom = lookup_widget (objet_graphique,"ikentry2");
prenom = lookup_widget (objet_graphique,"ikentry3");
classe= lookup_widget (objet_graphique,"ikentry7");


strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.classe,gtk_entry_get_text(GTK_ENTRY(classe)));


GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

jour=lookup_widget(objet_graphique,"ikspinbutton1");
mois=lookup_widget(objet_graphique,"ikspinbutton2");
annee=lookup_widget(objet_graphique,"ikspinbutton3");

e.date_entree.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
e.date_entree.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
e.date_entree.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
e.payement=payement;
if ((nbres(refch)==0||nbres(refch)==1))
 { ajouter_heb(e);
	     outputMsg=lookup_widget(objet_graphique,("iklabel30"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),"ajout reussi");}
else {outputMsg=lookup_widget(objet_graphique,("iklabel30"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),"ressayer");}}
else {outputMsg=lookup_widget(objet_graphique,("iklabel30"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),"ressayer");
}
}





void
on_ikradiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)));
payement=1;
}


void
on_ikradiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
payement=2;
}


void
on_ikbuttonV_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget  *combobox8,*combobox9,*combobox10,*id,*outputMsg;
char bloc[10];char etage[10];char num[10];
char ref[10];
char text[20];
id = lookup_widget (objet_graphique,"ikentry10");
combobox8 = lookup_widget (objet_graphique,"ikcombobox8");
combobox9 = lookup_widget (objet_graphique,"ikcombobox9");
combobox10 = lookup_widget (objet_graphique,"ikcombobox10");
if (strcmp("A",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"A");
if (strcmp("B",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"B");
if (strcmp("C",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"C");

if (strcmp("0",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"0");
if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"2");

if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"2");
if (strcmp("3",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"3");
if (strcmp("4",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"4");
if (strcmp("5",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"5");
if (strcmp("6",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"6");
if (strcmp("7",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"7");
if (strcmp("8",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"8");
strcpy(ref,strcat(strcat(bloc,etage),num));
strcpy(refch,ref);
eheb x;
FILE*f=NULL;
char refchh[10];

f=fopen("ikfichier.txt","r");

while(fscanf(f,"%s %s %s %s %s %d %d %d %d\n",x.id,x.nom,x.prenom,x.classe,
x.refch,&x.payement,&x.date_entree.jour,&x.date_entree.mois,&x.date_entree.annee)!=EOF){

if( strcmp(x.id,gtk_entry_get_text(GTK_ENTRY(id)))==0    )
strcpy(refchh,x.refch);

}
fclose(f);

if ((nbres(ref)<2)||(strcmp(ref,refchh)==0)){
strcpy (text,"disponible");
	     outputMsg=lookup_widget(objet_graphique,("iklabel29"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
else { strcpy (text,"non disponible");
	     outputMsg=lookup_widget(objet_graphique,("iklabel29"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);}
}


void
on_ikbuttonVV_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *idd, *outputMsg;
char id[20];
char text[20];
idd = lookup_widget (objet_graphique,"ikentry1");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idd)));
if (chercher_heb(id)==-1){
strcpy (text,"acceptable");
	     outputMsg=lookup_widget(objet_graphique,("iklabelv"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
else { strcpy (text,"non acceptable");
	     outputMsg=lookup_widget(objet_graphique,("iklabelv"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);}
}


void
on_ikbutton3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *idd,*nom,*prenom,*classe,*modifier,*outputMsg;
modifier=lookup_widget(button,"ikmodifier");
eheb e ;
char id[20];char text[100];
GtkWidget  *combobox8,*combobox9,*combobox10;
char bloc[10];char etage[10];char num[10];


idd = lookup_widget (button,"ikentry10");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idd)));
if (chercher_heb(id)!=-1)
{
strcpy(e.id,id);
combobox8 = lookup_widget (button,"ikcombobox15");
combobox9 = lookup_widget (button,"ikcombobox16");
combobox10 = lookup_widget (button,"ikcombobox14");
if (strcmp("A",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"A");
if (strcmp("B",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"B");
if (strcmp("C",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"C");

if (strcmp("0",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"0");
if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"2");

if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"2");
if (strcmp("3",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"3");
if (strcmp("4",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"4");
if (strcmp("5",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"5");
if (strcmp("6",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"6");
if (strcmp("7",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"7");
if (strcmp("8",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"8");
strcpy(e.refch,strcat(strcat(bloc,etage),num));

nom = lookup_widget (button,"ikentry5");
prenom = lookup_widget (button,"ikentry6");
classe= lookup_widget (button,"ikentry9");


strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(e.classe,gtk_entry_get_text(GTK_ENTRY(classe)));


GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

jour=lookup_widget(button,"ikspinbutton4");
mois=lookup_widget(button,"ikspinbutton5");
annee=lookup_widget(button,"ikspinbutton6");

e.date_entree.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
e.date_entree.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
e.date_entree.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
e.payement=payementm;
eheb x;
FILE*f=NULL;

char refchh[10];

f=fopen("ikfichier.txt","r");


while(fscanf(f,"%s %s %s %s %s %d %d %d %d\n",x.id,x.nom,x.prenom,x.classe,
x.refch,&x.payement,&x.date_entree.jour,&x.date_entree.mois,&x.date_entree.annee)!=EOF){

if( strcmp(x.id,e.id)==0    )

strcpy(refchh,x.refch);
}
fclose(f);

if ((strcmp(refchh,e.refch)==0)||(nbres(e.refch)<2)){
 modifier_heb(e);
	   
outputMsg=lookup_widget(button,("iklabel34"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),"modification faite");}
else {outputMsg=lookup_widget(button,("iklabel34"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),"ressayer");}}
else {outputMsg=lookup_widget(button,("iklabel34"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),"ressayer");
}
}


void
on_ikbutton4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_ikbutton5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *idd, *outputMsg;
char id[20];
char text[30];
idd = lookup_widget (button,"ikentry11");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idd)));
if (chercher_heb(id)==-1){
strcpy (text,"id introuvable");
	     outputMsg=lookup_widget(button,("iklabel39"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
else {if(supp==1){supprimer_heb(id);
 strcpy (text,"suppression avec succes");
	     outputMsg=lookup_widget(button,"iklabel39");
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);}}

}


void
on_ikcheckbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
supp=1;
}


void
on_ikcheckbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
supp=0;
}


void
on_ikbutton8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget  *combobox8,*combobox9,*combobox10,*outputMsg;
char bloc[10];char etage[10];char num[10];
char ref[10];
char text[20];
combobox8 = lookup_widget (button,"ikcombobox15");
combobox9 = lookup_widget (button,"ikcombobox16");
combobox10 = lookup_widget (button,"ikcombobox14");
if (strcmp("A",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"A");
if (strcmp("B",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"B");
if (strcmp("C",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox8)))==0)
strcpy(bloc,"C");

if (strcmp("0",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"0");
if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox9)))==0)
strcpy(etage,"2");

if (strcmp("1",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"1");
if (strcmp("2",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"2");
if (strcmp("3",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"3");
if (strcmp("4",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"4");
if (strcmp("5",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"5");
if (strcmp("6",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"6");
if (strcmp("7",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"7");
if (strcmp("8",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox10)))==0)
strcpy(num,"8");
strcpy(ref,strcat(strcat(bloc,etage),num));
strcpy(refch,ref);
if (nbres(ref)==0||nbres(ref)==1){
strcpy (text,"disponible");
	     outputMsg=lookup_widget(button,("iklabel41"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
else { strcpy (text,"non disponible");
	     outputMsg=lookup_widget(button,("iklabel41"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);}
}


void
on_ikbutton7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *idd, *outputMsg;
char id[20];
char text[20];
idd = lookup_widget (button,"ikentry10");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idd)));
if (chercher_heb(id)==-1){
strcpy (text,"n'existe pas");
	     outputMsg=lookup_widget(button,("iklabel40"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);
}
else { strcpy (text,"ok");
	     outputMsg=lookup_widget(button,("iklabel40"));
	     gtk_label_set_text(GTK_LABEL(outputMsg),text);}
}


void
on_ikbutton9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview,*principale;
principale=lookup_widget(button,"ikprincipale");
treeview=lookup_widget(principale,"iktreeview1");
affich(treeview);
}


void
on_ikradiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)));
payementm=2;
}


void
on_ikradiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
(gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)));
payementm=1;
}


void
on_ikbutton11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkNotebook   *notebook1;
	GtkWidget *entryid; 
entryid=lookup_widget(button,"ikentry11");

	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;

	gchar *id ;
	
        p=lookup_widget(button,"iktreeview2");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,-1);

gtk_entry_set_text (GTK_ENTRY(entryid),id);
      	
 //gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
notebook1=(GTK_NOTEBOOK(lookup_widget(button,"iknotebook2")));
gint page = gtk_notebook_get_current_page (notebook1);
gtk_notebook_set_current_page (notebook1, 3);
}
}



void
on_ikbutton10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkNotebook   *notebook1;
	GtkWidget *entryid; GtkWidget *entrynom; GtkWidget *entryprenom;
	GtkWidget *entryclasse; GtkWidget *combobox8;GtkWidget *combobox9;GtkWidget *combobox10;GtkWidget *entryjour;GtkWidget *entrymois;GtkWidget *entryannee;  GtkWidget *entrypayement;
entryid=lookup_widget(button,"ikentry10");
entrynom=lookup_widget(button,"ikentry5"); 
entryprenom=lookup_widget(button,"ikentry6");
entryclasse=lookup_widget(button,"ikentry9");
combobox10=lookup_widget(button,"ikcombobox14");
combobox8=lookup_widget(button,"ikcombobox15");
combobox9=lookup_widget(button,"ikcombobox16");
	GtkTreeModel     *model;
        GtkTreeSelection *selection;
        GtkTreeIter iter;
        GtkWidget* p;

	gchar *id ;
	gchar *nom ;
	gchar *prenom;
	gchar *classe ;
	gchar *refch;
	gint *jour;
	gint *mois;
	gint *annee;
	gint *payement;
        p=lookup_widget(button,"iktreeview2");
        selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(p));
        if (gtk_tree_selection_get_selected(selection, &model, &iter))
        {  gtk_tree_model_get (model,&iter,0,&id,1,&nom,2,&prenom,3,&classe,4,&refch,5,&jour,6,&mois,7,&annee,8,payement,-1);

gtk_entry_set_text (GTK_ENTRY(entryid),id);
gtk_entry_set_text (GTK_ENTRY(entrynom),nom);
gtk_entry_set_text (GTK_ENTRY(entryprenom),prenom);
gtk_entry_set_text (GTK_ENTRY(entryclasse),classe);
if ('A'==refch[0])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox8),0);
if ('B'==refch[0])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox8),1);
if ('C'==refch[0])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox8),2);
if ('0'==refch[1])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox9),0);
if ('1'==refch[1])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox9),1);
if ('2'==refch[1])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox9),2);

 if ('1'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),0);
 if ('2'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),1);
 if ('3'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),2);
 if ('4'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),3);
 if ('5'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),4);
 if ('6'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),5);
 if ('7'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),6);
 if ('8'==refch[2])
gtk_combo_box_set_active(GTK_COMBO_BOX(combobox10),7);

          	
 //gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
notebook1=(GTK_NOTEBOOK(lookup_widget(button,"iknotebook2")));
gint page = gtk_notebook_get_current_page (notebook1);
gtk_notebook_set_current_page (notebook1, 2);
}
}


void
on_ikbutton12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(button,"iknotebook2")));
}


void
on_ikbutton13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkNotebook   *notebook1;

      	
 //gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
notebook1=(GTK_NOTEBOOK(lookup_widget(button,"iknotebook2")));
gint page = gtk_notebook_get_current_page (notebook1);
gtk_notebook_set_current_page (notebook1, 0);

}


void
on_ikbutton14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkNotebook   *notebook1;

      	
 //gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
notebook1=(GTK_NOTEBOOK(lookup_widget(button,"iknotebook2")));
gint page = gtk_notebook_get_current_page (notebook1);
gtk_notebook_set_current_page (notebook1, 0);
}


void
on_ikbutton15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkNotebook   *notebook1;

      	
 //gtk_list_store_remove(GTK_LIST_STORE(model),&iter);
notebook1=(GTK_NOTEBOOK(lookup_widget(button,"iknotebook2")));
gint page = gtk_notebook_get_current_page (notebook1);
gtk_notebook_set_current_page (notebook1, 0);
}



